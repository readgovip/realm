./realm -c config.json
